# Alarm-clock



<h1> Import Required Library</h2>
<ol>
<li>from tkinter import *</li>
<li>import datetime</li>
<li>import time</li>
<li>import winsound</li>
<li>from threading import *</li>
</ol>
<hr>


<h1><b>Screenshot of this project.</b></h1>

<img src="Screenshot 2022-11-27 122619.png">
